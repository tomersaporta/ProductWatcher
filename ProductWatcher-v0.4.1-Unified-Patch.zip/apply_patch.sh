#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -d app/src/main/java/com/productwatcher/app ]]; then
  echo "Run from the root of the ProductWatcher repository." >&2; exit 1
fi
# Historical local-folder scanning was intentionally retired. Never touch user gallery content.
rm -f app/src/main/java/com/productwatcher/app/ScanWorker.kt
for pair in 'MonitorControl.kt:ensureAutomatic' 'TelegramClient.kt:deleteDownloadedPhoto' 'OfferExtractor.kt:OfferExtractor' 'Store.kt:ensureScannerUpgrade'; do
  file=${pair%%:*}; needle=${pair#*:}
  grep -q "$needle" "app/src/main/java/com/productwatcher/app/$file" || { echo "Missing $needle" >&2; exit 1; }
done
grep -q 'lib-tdlib-android' app/build.gradle.kts || { echo 'Missing TDLib dependency' >&2; exit 1; }
grep -q 'jitpack.io' settings.gradle.kts || { echo 'Missing JitPack repository' >&2; exit 1; }
grep -q 'versionName = "0.4.1"' app/build.gradle.kts || { echo 'Wrong version' >&2; exit 1; }
echo 'ProductWatcher v0.4.1 files installed. Build in GitHub Actions or Codespaces and install latest APK.'
