Build failure at 2026-10-24 19:38:09Z:
Android SDK package tools no longer exists. android-actions/setup-android@v3
implicitly requested tools platform-tools. v4 with packages platform-tools fixes this.

INSTALL: unzip -o ProductWatcher-v0.4.1-CI-Fixed-Patch.zip && bash apply_patch.sh && git add -A && git commit -m "Fix Android SDK setup and unify OCR patches" && git push origin main

Note: The project still needs GitHub Actions to verify Android compilation, unit tests and APK.
