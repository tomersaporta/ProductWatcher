# ProductWatcher — Telegram deal monitor (Android)

This Android application monitors Telegram channels selected by the user through the local TDLib client, reads text from posted photos on-device using bundled Google ML Kit Latin OCR, and sends Android notifications for watched product models.

## Features

- Connects directly to the account's Telegram channels using TDLib; **no forwarding and no external server**.
- Watches several product names and several selected channels.
- Distinguishes `Dreame X60 Ultra` / `X60 Ultra Complete` from `Dreame X60 Pro Ultra`, `X60 Max Ultra`, `X50 Ultra` and `X40 Ultra`.
- Associates prices to product names using the locations of recognized text lines; with multiple prices, reports *price unknown* when assignment is ambiguous rather than taking the first price.
- Background monitoring starts automatically when a channel is selected; explicit Stop is remembered.
- On app open, restarts monitoring if it was enabled. On reboot, WorkManager re-registers periodic catch-up; Android 15+ may defer scans and impose a foreground-service quota.
- New watched product automatically triggers bounded full Telegram-history rescan; progress/cursor survives process recreation. Recent posts are checked first, historical messages in groups of up to four pages (400 posts) per scan cycle. Missing-post gaps after long background suspension are backfilled separately.
- At most three photos are downloaded/OCR'd concurrently. Failed downloads or OCR processing retry on later cycles (last 150 failed IDs per channel tracked).
- After successful OCR, can delete the **TDLib local cached file only**. Never deletes a Telegram post or a user's gallery photo.
- Status for each watched product: last activity, checked posts, matches, alerts, last matching product/price. Channel status: counts, OCR preview, backfill progress.

## Install/update through GitHub Codespaces

From your existing `tomersaporta/ProductWatcher` Codespace, upload `ProductWatcher-v0.4.1-Unified-Patch.zip` to the repository root, then:

```bash
unzip -o ProductWatcher-v0.4.1-Unified-Patch.zip
bash apply_patch.sh
git add -A
git commit -m "Repair Telegram OCR, product matching, rescan and monitoring"
git push origin main
```

Your Telegram session and watchlist are stored in local app data. An APK update preserves them ONLY if it uses the same application ID and signing certificate. GitHub Actions debug builds may generate a new key on each run, causing Android to reject an upgrade. Do not uninstall or clear data until you are prepared to reauthenticate and reconfigure the watchlist.

GitHub Actions runs Kotlin regression tests and creates the `ProductWatcher-debug-apk` artifact. Inspect Actions for `BUILD SUCCESSFUL` before installing.

## Verification

JVM-only model matching regression tests also run without an Android SDK:

```bash
kotlinc app/src/main/java/com/productwatcher/app/{Matcher.kt,OfferExtractor.kt} MatcherRegression.kt -include-runtime -d matcher-test.jar
java -jar matcher-test.jar
```

On Android: open the app, verify the monitor is enabled and your Telegram source is listed. Click **Rescan full Telegram history** if the image was posted before this version was installed, then watch the per-channel history cursor, last OCR text and per-product counters. On the supplied multi-product sample, a successful OCR should identify `X60 Ultra Complete` and, if it can read the tag, associate **₪3,799**. The separate `X50 Ultra` and `X40 Ultra Complete` tags show ₪2,450 and ₪1,790. The sample must **not** trigger an `X60 Pro Ultra` alert.

## Known limits

- Google ML Kit Latin recognition does not reliably read Hebrew store branch names. Branches are displayed as unidentified rather than fabricated.
- Image OCR accuracy varies with photograph resolution, glare and font size; price/model matching is only as good as the recognized text. OCR snippets are for diagnosis and stay on-device unless the user explicitly shares a status report.
- Android background execution is best effort: exact 24/7 live monitoring and instant notification are not guaranteed by WorkManager or foreground-service quotas.
- The Kotlin matching/extraction logic has been tested in a local JVM, but this patch has **not** been compiled into an Android APK or verified against a real Telegram session here. The GitHub Actions build and device testing are still required.

## v0.4.1 upgrade diagnostics

- The header displays `v0.4.1` so users can distinguish the corrected APK from an older one.
- On the FIRST opening of this version, the app triggers a full historical rescan without removing existing product names.
- Generic `Dreame X60` searches match the X60 family; `X60 Ultra` still excludes Pro and Max.
- The monitor shows images started, successful OCR, currently queued images and failed attempts separately.
- `Test one image (OCR diagnostics)` opens a single gallery image and displays recognized raw text and independent per-product matches. It does not scan the gallery or delete the selected image.
- The build includes the TDLib JitPack dependency; older patch packages accidentally omitted it.
